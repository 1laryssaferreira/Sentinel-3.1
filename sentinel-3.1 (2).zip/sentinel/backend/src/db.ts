import 'dotenv/config';
import mysql from 'mysql2/promise';

// Um "pool" reaproveita as conexões com o MySQL em vez de abrir uma nova a cada pedido.
export const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'sentinel_db',
  dateStrings: true
});

export async function testarConexaoBanco() {
  try {
    await pool.query('SELECT 1');
    console.log('✅ Conectado ao MySQL:', process.env.DB_NAME || 'sentinel_db');
  } catch (erro: any) {
    console.error('❌ Sem conexão com o MySQL:', erro.message);
  }
}
