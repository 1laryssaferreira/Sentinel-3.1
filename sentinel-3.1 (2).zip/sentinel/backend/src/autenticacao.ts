import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

export const JWT_SECRET = process.env.JWT_SECRET || 'sentinel-dev';

export interface RequisicaoComUsuario extends Request {
  usuario?: { id: number; nome: string; email: string; papel: string };
}

// Middleware: só deixa passar quem mandou um token válido no cabeçalho Authorization.
export function exigirLogin(req: RequisicaoComUsuario, res: Response, next: NextFunction) {
  const token = req.headers.authorization?.replace('Bearer ', '') || '';
  try {
    req.usuario = jwt.verify(token, JWT_SECRET) as RequisicaoComUsuario['usuario'];
    next();
  } catch {
    res.status(401).json({ erro: 'Faça login novamente.' });
  }
}
