import { pool } from '../db';

// ==========================================================
// ASSISTENTE COM LLAMA (IA generativa, pelo Ollama — grátis, roda no PC)
//
// Como o Llama "faz coisas" no painel: tool calling.
// Passamos para o modelo uma lista de ferramentas. Quando ele
// decide usar uma:
//   - se for uma CONSULTA ao banco (eventos, acessos, moradores,
//     emergências), o servidor executa aqui e devolve o resultado
//     para o Llama continuar a resposta;
//   - se for uma AÇÃO no painel (porta, janela, câmera, emergência),
//     o servidor devolve para o front-end, que executa.
// ==========================================================
export interface MensagemChat { papel: 'usuario' | 'assistente'; texto: string }
export interface AcaoPainel { nome: string; argumentos: Record<string, unknown> }

export function configuracaoLlama() {
  const url = (process.env.OLLAMA_URL || process.env.OPENAI_BASE_URL || '').replace(/\/v1\/?$/, '').replace(/\/$/, '');
  return { ativa: Boolean(url), url, modelo: process.env.OLLAMA_MODEL || process.env.OPENAI_MODEL || 'llama3.1' };
}

const ferramenta = (name: string, description: string, properties: object = {}, required: string[] = []) =>
  ({ type: 'function', function: { name, description, parameters: { type: 'object', properties, required } } });

const limite = { limite: { type: 'integer', description: 'Quantos registros (padrão 10)' } };

const FERRAMENTAS = [
  // Ações no painel
  ferramenta('definir_porta', 'Tranca ou destranca a porta principal.',
    { estado: { type: 'string', enum: ['trancada', 'aberta'] } }, ['estado']),
  ferramenta('definir_janela', 'Abre ou fecha a janela da sala.',
    { estado: { type: 'string', enum: ['fechada', 'aberta'] } }, ['estado']),
  ferramenta('abrir_camera', 'Abre a visualização de uma câmera pelo nome (ex.: "Entrada principal", "Quintal").',
    { nome: { type: 'string' } }, ['nome']),
  ferramenta('acionar_emergencia', 'Aciona polícia (190) ou bombeiros (193). Use SOMENTE com pedido explícito ou emergência real descrita.',
    { servico: { type: 'string', enum: ['POLICIA', 'BOMBEIROS'] }, motivo: { type: 'string' } }, ['servico', 'motivo']),
  // Consultas ao MySQL
  ferramenta('consultar_eventos', 'Lê os eventos mais recentes da casa no banco.', limite),
  ferramenta('consultar_acessos', 'Lê quem foi liberado, negado ou procurado pelo reconhecimento facial.', limite),
  ferramenta('consultar_moradores', 'Lista os moradores com rosto cadastrado.'),
  ferramenta('consultar_emergencias', 'Lê as chamadas de emergência simuladas já feitas.', limite)
];

const CONSULTAS: Record<string, string> = {
  consultar_eventos: 'SELECT tipo, status, criado_em FROM eventos ORDER BY id DESC LIMIT ?',
  consultar_acessos: `SELECT a.resultado, a.camera, a.criado_em, b.nome AS morador
                      FROM acessos a LEFT JOIN biometria b ON b.id = a.biometria_id ORDER BY a.id DESC LIMIT ?`,
  consultar_moradores: 'SELECT nome, criado_em FROM biometria ORDER BY nome LIMIT ?',
  consultar_emergencias: 'SELECT servico, motivo, risco_no_momento, automatico, criado_em FROM acionamentos ORDER BY id DESC LIMIT ?'
};

async function executarConsulta(nome: string, argumentos: any) {
  const quantidade = Math.min(Math.max(Number(argumentos?.limite) || 10, 1), 30);
  try {
    const [linhas] = await pool.query(CONSULTAS[nome], [quantidade]);
    return JSON.stringify(linhas);
  } catch {
    return JSON.stringify({ erro: 'Banco de dados indisponível no momento.' });
  }
}

function instrucoes(estado: unknown, operador: string) {
  const agora = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
  return [
    'Você é a Sentinel, assistente de uma central de monitoramento residencial.',
    `Você está falando com ${operador}. Data e hora: ${agora}.`,
    '',
    'Como responder:',
    '- Português do Brasil, frases curtas e diretas, tom calmo. Sem markdown pesado.',
    '- Baseie-se SOMENTE no estado abaixo e no que as ferramentas de consulta retornarem. Se não souber, diga que não sabe.',
    '- Quando pedirem uma ação (trancar a porta, fechar a janela, abrir uma câmera), use a ferramenta e confirme em uma frase.',
    '- Só acione polícia ou bombeiros com pedido explícito ou emergência real descrita. Em dúvida, pergunte.',
    '- Em risco alto, comece pela informação mais importante e diga o que fazer agora.',
    '- Você não vê as imagens das câmeras; sabe apenas o que o estado e o histórico informam.',
    '',
    'Estado atual da casa (enviado pelo painel):',
    JSON.stringify(estado, null, 2)
  ].join('\n');
}

const MAX_RODADAS = 4;

export async function conversar(historico: MensagemChat[], estado: unknown, operador: string) {
  const { url, modelo } = configuracaoLlama();
  const mensagens: any[] = [
    { role: 'system', content: instrucoes(estado, operador) },
    ...historico.slice(-12).map(m => ({ role: m.papel === 'usuario' ? 'user' : 'assistant', content: m.texto }))
  ];
  const acoes: AcaoPainel[] = [];
  let resposta = '';

  // O Llama pode pedir ferramentas, ver o resultado e continuar: até 4 rodadas.
  for (let rodada = 0; rodada < MAX_RODADAS; rodada++) {
    const r = await fetch(`${url}/v1/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ollama' },
      signal: AbortSignal.timeout(90000),
      body: JSON.stringify({ model: modelo, messages: mensagens, tools: FERRAMENTAS, temperature: 0.3 })
    });
    if (!r.ok) throw new Error(`Ollama respondeu ${r.status}`);

    const mensagem = ((await r.json()) as any).choices?.[0]?.message || {};
    if (mensagem.content) resposta = String(mensagem.content).trim();
    const chamadas: any[] = mensagem.tool_calls || [];
    if (!chamadas.length) break;

    mensagens.push(mensagem);
    for (const chamada of chamadas) {
      const nome = chamada.function?.name;
      let argumentos: any = {};
      try { argumentos = JSON.parse(chamada.function?.arguments || '{}'); } catch { /* argumentos inválidos */ }

      let resultado: string;
      if (CONSULTAS[nome]) {
        resultado = await executarConsulta(nome, argumentos);
      } else {
        acoes.push({ nome, argumentos });
        resultado = JSON.stringify({ ok: true, observacao: 'Ação enviada ao painel.' });
      }
      mensagens.push({ role: 'tool', tool_call_id: chamada.id, content: resultado });
    }
  }

  return { resposta: resposta || 'Feito.', acoes, modelo };
}
