import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';

// Cria o banco, as tabelas e as duas contas de teste (administrador e usuário).
async function migrar() {
  const conexao = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true
  });
  try {
    await conexao.query(fs.readFileSync(path.join(__dirname, '..', 'sql', 'schema.sql'), 'utf-8'));
    const senha = await bcrypt.hash('Sentinel123', 10);
    await conexao.query(
      `INSERT IGNORE INTO usuarios (nome, email, senha_hash, papel) VALUES
       ('Operador Sentinel', 'operador@sentinel.com', ?, 'Administrador'),
       ('Usuário Sentinel', 'usuario@sentinel.com', ?, 'Usuário')`,
      [senha, senha]
    );
    console.log('✅ Banco pronto. Contas de teste (senha Sentinel123): operador@sentinel.com e usuario@sentinel.com');
  } finally {
    await conexao.end();
  }
}

migrar().catch((erro) => {
  console.error('❌ Erro na migração:', erro.message);
  process.exit(1);
});
