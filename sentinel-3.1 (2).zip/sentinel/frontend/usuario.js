// ==========================================================
// TELA DO USUÁRIO / MORADOR (Gabriel)
// Mesma ideia da versão 2.1: câmeras, estado da casa, histórico
// com filtro e assistente, numa tela mais simples que a central.
// ==========================================================
function carregarUsuario() {
  document.getElementById('welcomeName').textContent = getSession().name.split(' ')[0];
}

function atualizarRelogio() {
  document.getElementById('relogio').textContent = `Agora: ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
}

// Esconde os itens do histórico que não são do tipo escolhido.
function filtrarHistorico() {
  const filtro = document.getElementById('historyFilter').value;
  document.querySelectorAll('#logFeed li').forEach(item => {
    item.style.display = filtro === 'all' || item.dataset.tipo === filtro ? '' : 'none';
  });
}

window.addEventListener('DOMContentLoaded', () => {
  if (!getSession()) return;
  carregarUsuario();
  atualizarRelogio();
  setInterval(atualizarRelogio, 30000);
  aoConectarSocket((s) => iniciarCelulares(s, null));
});
