// ==========================================================
// CELULAR COMO CÂMERA (integração)
// O celular abre celular.html e transmite. O painel recebe o
// vídeo direto do celular por WebRTC; o servidor (Socket.IO)
// só apresenta um ao outro.
// ==========================================================
const camerasCelular = new Map(); // id da conexão → { nome, stream, pc, card }
const STUN = [{ urls: 'stun:stun.l.google.com:19302' }];

function iniciarCelulares(socket, aoClicar) {
  socket.on('camera:nova', ({ socketId, nome }) => conectarCelular(socket, socketId, nome, aoClicar));
  socket.on('camera:saiu', ({ socketId }) => removerCelular(socketId));
  socket.on('sinal:answer', ({ de, dados }) => camerasCelular.get(de)?.pc.setRemoteDescription(dados));
  socket.on('sinal:ice', ({ de, dados }) => camerasCelular.get(de)?.pc.addIceCandidate(dados).catch(() => {}));
}

async function conectarCelular(socket, id, nome, aoClicar) {
  removerCelular(id);
  const card = document.createElement('div');
  card.className = 'tile';
  card.innerHTML = `<div class="tile-tela"><video autoplay muted playsinline></video>
    <div class="tile-carregando">Conectando ao celular…</div>
    <div class="tile-osd"><span class="tile-nome osd"><span></span><span class="tile-tipo">CELULAR</span></span></div></div>
    <div class="tile-rodape"><span class="tile-rotulo"></span><span class="tile-estado">Ao vivo</span></div>`;
  card.querySelector('.tile-nome span').textContent = nome;
  card.querySelector('.tile-rotulo').textContent = nome;
  const video = card.querySelector('video');
  video.addEventListener('loadeddata', () => card.querySelector('.tile-carregando')?.remove(), { once: true });
  if (aoClicar) card.querySelector('.tile-tela').onclick = () => aoClicar(id, nome);

  // Ocupa o lugar de uma das câmeras desligadas da planta (Sala, Quintal).
  const parede = document.getElementById('paredeCameras');
  const vagas = [...parede.querySelectorAll('[data-vaga]:not([hidden])')];
  const vaga = vagas.find(v => nome.toLowerCase().includes(v.dataset.vaga.split(' ')[0].toLowerCase())) || vagas[0];
  if (vaga) vaga.hidden = true;
  parede.insertBefore(card, parede.querySelector('[data-vaga]') || null);

  // O painel manda um convite (offer); o celular responde com o vídeo.
  const pc = new RTCPeerConnection({ iceServers: STUN });
  const camera = { nome, pc, card, vaga, stream: null };
  camerasCelular.set(id, camera);
  pc.addTransceiver('video', { direction: 'recvonly' });
  pc.ontrack = (e) => { camera.stream = e.streams[0]; video.srcObject = camera.stream; };
  pc.onicecandidate = (e) => e.candidate && socket.emit('sinal:ice', { para: id, dados: e.candidate });
  await pc.setLocalDescription(await pc.createOffer());
  socket.emit('sinal:offer', { para: id, dados: pc.localDescription });
  if (typeof enviarEventoBackend === 'function' && document.body.dataset.pagina === 'administrador') {
    enviarEventoBackend('Câmeras', `Celular "${nome}" conectado`);
  }
}

function removerCelular(id) {
  const camera = camerasCelular.get(id);
  if (!camera) return;
  camera.pc.close();
  camera.card.remove();
  if (camera.vaga) camera.vaga.hidden = false;
  camerasCelular.delete(id);
}

const listarCameras = () => [...camerasCelular.values()].map(c => c.nome);

// Janela com o QR Code que o celular escaneia.
async function abrirDialogoCelular() {
  document.getElementById('dlgCelular').showModal();
  const qrEl = document.getElementById('qrCelular');
  const urlEl = document.getElementById('urlCelular');
  qrEl.textContent = '';
  const { ok, dados } = await api('/rede').catch(() => ({}));
  if (!ok) { urlEl.textContent = 'Servidor fora do ar'; return; }

  const local = ['localhost', '127.0.0.1'].includes(location.hostname);
  const publicado = !local && location.port === '';
  const ip = local ? dados.ips[0] : location.hostname;
  const url = publicado ? `${location.origin}/celular.html`
    : dados.portaHttps ? `https://${ip}:${dados.portaHttps}/celular.html` : `http://${ip}:${dados.portaHttp}/celular.html`;
  urlEl.textContent = url;
  document.getElementById('avisoHttps').hidden = url.startsWith('https');
  const qr = qrcode(0, 'M');
  qr.addData(url);
  qr.make();
  qrEl.innerHTML = qr.createSvgTag({ cellSize: 5, margin: 2, scalable: true });
}
