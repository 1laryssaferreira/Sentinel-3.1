import { Router } from 'express';
import { pool } from '../db';
import { avisarPaineis } from '../tempoReal';

// ==========================================================
// ESTADO DA CASA E EMERGÊNCIA
// O servidor guarda o estado dos sensores para que todas as telas
// abertas (central e tela do usuário) mostrem a mesma coisa.
// ==========================================================
const router = Router();

const estadoSistema: Record<string, boolean> = {
  portaPrincipal: false,
  janelaSala: false,
  incendioDetectado: false,
  gasDetectado: false,
  alertaPolicial: false
};

/**
 * @swagger
 * /api/casa:
 *   get:
 *     summary: Estado atual dos sensores da casa
 *     tags: [Casa]
 */
router.get('/casa', (_req, res) => res.json(estadoSistema));

/**
 * @swagger
 * /api/casa/{sensor}:
 *   put:
 *     summary: Muda um sensor e avisa todas as telas abertas
 *     tags: [Casa]
 *     parameters:
 *       - { name: sensor, in: path, required: true, schema: { type: string, example: portaPrincipal } }
 *     requestBody:
 *       content:
 *         application/json:
 *           example: { "ativo": true }
 */
router.put('/casa/:sensor', (req, res) => {
  const sensor = req.params.sensor;
  if (!(sensor in estadoSistema)) return res.status(400).json({ erro: 'Sensor desconhecido.' });
  estadoSistema[sensor] = Boolean(req.body.ativo);
  avisarPaineis('casa:atualizada', estadoSistema);
  res.json(estadoSistema);
});

/**
 * @swagger
 * /api/emergencia:
 *   post:
 *     summary: Registra uma chamada de emergência SIMULADA (nenhuma ligação real é feita)
 *     tags: [Casa]
 *     requestBody:
 *       content:
 *         application/json:
 *           example: { "servico": "BOMBEIROS", "motivo": "Fumaça na cozinha", "risco": 100, "automatico": true }
 *   get:
 *     summary: Histórico de chamadas simuladas
 *     tags: [Casa]
 */
router.post('/emergencia', async (req, res) => {
  const { servico, motivo, risco = 0, automatico = false } = req.body;
  if (!['POLICIA', 'BOMBEIROS'].includes(servico) || !motivo) {
    return res.status(400).json({ erro: 'Informe o serviço (POLICIA ou BOMBEIROS) e o motivo.' });
  }
  try {
    await pool.query('INSERT INTO acionamentos (servico, motivo, risco_no_momento, automatico) VALUES (?, ?, ?, ?)',
      [servico, motivo, risco, automatico ? 1 : 0]);
    avisarPaineis('emergencia:nova', { servico, motivo });
    res.status(201).json({ servico, motivo, simulado: true });
  } catch {
    res.status(500).json({ erro: 'Erro no banco de dados.' });
  }
});

router.get('/emergencia', async (_req, res) => {
  try {
    const [linhas] = await pool.query('SELECT * FROM acionamentos ORDER BY id DESC LIMIT 20');
    res.json(linhas);
  } catch {
    res.status(500).json({ erro: 'Erro no banco de dados.' });
  }
});

export default router;
