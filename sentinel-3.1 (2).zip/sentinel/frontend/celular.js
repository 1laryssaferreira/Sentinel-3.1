// ==========================================================
// CÂMERA DO CELULAR — envia o vídeo para o painel.
// O servidor (Socket.IO) só apresenta o celular ao painel;
// o vídeo vai direto de um para o outro por WebRTC.
// ==========================================================
const STUN = [{ urls: 'stun:stun.l.google.com:19302' }];
const el = (id) => document.getElementById(id);

let stream = null;
let socket = null;
const conexoes = new Map(); // painel → conexão WebRTC

function estado(texto, tom = '') {
  el('estadoTexto').textContent = texto;
  el('estado').dataset.tom = tom;
}

function erro(texto) {
  el('erro').textContent = texto;
  el('erro').hidden = !texto;
}

setInterval(() => { el('relogio').textContent = new Date().toLocaleString('pt-BR'); }, 1000);

async function abrirCamera() {
  if (!window.isSecureContext) {
    estado('Página não segura', 'perigo');
    return erro('A câmera só abre em página https://. Use o QR Code do painel.');
  }
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1280 } }, audio: false });
    el('videoCelular').srcObject = stream;
    el('btnConectar').disabled = false;
    estado('Câmera pronta');
  } catch (e) {
    estado('Câmera bloqueada', 'perigo');
    erro(e.name === 'NotAllowedError' ? 'Permissão negada. Toque no cadeado da barra de endereço e libere a câmera.' : e.message);
  }
}

function atualizarAssistindo() {
  const n = [...conexoes.values()].filter(pc => pc.connectionState === 'connected').length;
  el('assistindo').textContent = n ? `${n} painel(is) assistindo` : 'Nenhum painel assistindo';
  if (socket) estado(n ? 'Transmitindo' : 'Aguardando o painel…', n ? 'ok' : 'atencao');
}

// Cada painel que abrir manda um "convite" (offer); o celular responde e envia o vídeo.
async function responderPainel({ de, dados }) {
  conexoes.get(de)?.close();
  const pc = new RTCPeerConnection({ iceServers: STUN });
  conexoes.set(de, pc);
  stream.getTracks().forEach(t => pc.addTrack(t, stream));
  pc.onicecandidate = (e) => e.candidate && socket.emit('sinal:ice', { para: de, dados: e.candidate });
  pc.onconnectionstatechange = atualizarAssistindo;

  await pc.setRemoteDescription(dados);
  await pc.setLocalDescription(await pc.createAnswer());
  socket.emit('sinal:answer', { para: de, dados: pc.localDescription });
}

function comecar(nome) {
  socket = io();
  socket.on('connect', () => { socket.emit('camera:entrar', { nome }); atualizarAssistindo(); });
  socket.on('disconnect', () => estado('Sem conexão, tentando de novo…', 'perigo'));
  socket.on('sinal:offer', responderPainel);
  socket.on('sinal:ice', ({ de, dados }) => conexoes.get(de)?.addIceCandidate(dados).catch(() => {}));
  socket.on('painel:saiu', ({ socketId }) => { conexoes.get(socketId)?.close(); conexoes.delete(socketId); atualizarAssistindo(); });
  navigator.wakeLock?.request('screen').catch(() => {}); // mantém a tela acesa
}

function parar() {
  socket?.disconnect();
  socket = null;
  conexoes.forEach(pc => pc.close());
  conexoes.clear();
  el('formCelular').hidden = false;
  el('btnParar').hidden = true;
  estado('Transmissão parada');
  atualizarAssistindo();
}

el('nomeCamera').value = localStorage.getItem('sentinel_nome_camera') || '';

el('formCelular').addEventListener('submit', (e) => {
  e.preventDefault();
  const nome = el('nomeCamera').value.trim();
  if (!nome || !stream) return;
  localStorage.setItem('sentinel_nome_camera', nome);
  erro('');
  el('formCelular').hidden = true;
  el('btnParar').hidden = false;
  estado('Conectando…', 'atencao');
  comecar(nome);
});
el('btnParar').addEventListener('click', parar);

abrirCamera();
