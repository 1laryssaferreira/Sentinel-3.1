// ==========================================================
// CHAT DO ASSISTENTE (Llama)
// A tela manda a conversa e o estado da casa para o servidor.
// O Llama responde e devolve as ações que o painel executa
// (porta, janela, câmera, emergência). Cada ação feita aparece
// como um selo verde embaixo da resposta.
// ==========================================================
const historicoChat = [];

function adicionarMensagemChat(texto, classe, selos = []) {
  const lista = document.getElementById('chatHistory');
  const bolha = document.createElement('div');
  bolha.className = `bolha ${classe === 'user-msg' ? 'bolha-eu' : classe === 'erro' ? 'bolha-ia erro' : 'bolha-ia'}`;
  bolha.textContent = texto;
  lista.appendChild(bolha);
  if (selos.length) {
    const area = document.createElement('div');
    area.className = 'acoes-feitas';
    selos.forEach(t => { const s = document.createElement('span'); s.textContent = t; area.appendChild(s); });
    lista.appendChild(area);
  }
  lista.scrollTop = lista.scrollHeight;
}

function verificarEnter(event) {
  if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); enviarMensagem(); }
}

function perguntaRapida(texto) {
  document.getElementById('chatInput').value = texto;
  enviarMensagem();
}

function enviarMensagem() {
  const campo = document.getElementById('chatInput');
  const texto = campo.value.trim();
  if (!texto) return;
  campo.value = '';
  adicionarMensagemChat(texto, 'user-msg');
  processarIntencaoBot(texto);
}

let aguardandoLlama = false;

async function processarIntencaoBot(msg) {
  if (aguardandoLlama) return;
  aguardandoLlama = true;
  historicoChat.push({ papel: 'usuario', texto: msg });

  const digitando = document.createElement('div');
  digitando.className = 'digitando';
  digitando.innerHTML = '<i></i><i></i><i></i>';
  document.getElementById('chatHistory').appendChild(digitando);

  try {
    const { ok, dados } = await api('/assistente/mensagem', {
      method: 'POST', body: { mensagens: historicoChat.slice(-12), estado: obterEstadoCasa() }
    });
    if (!ok) throw new Error(dados?.erro || 'O Llama não respondeu.');
    const selos = dados.acoes.map(a => executarAcao(a.nome, a.argumentos)).filter(Boolean);
    adicionarMensagemChat(dados.resposta, 'system-msg', selos);
    historicoChat.push({ papel: 'assistente', texto: dados.resposta });
  } catch (erro) {
    historicoChat.pop(); // a pergunta sem resposta não entra no histórico
    adicionarMensagemChat(erro.message === 'Failed to fetch' ? 'O servidor não respondeu.' : erro.message, 'erro');
  } finally {
    digitando.remove();
    aguardandoLlama = false;
  }
}

// Executa no painel a ação que o Llama pediu e devolve o texto do selo.
function executarAcao(nome, args = {}) {
  switch (nome) {
    case 'definir_porta': {
      const abrir = String(args.estado).startsWith('abert');
      if (estadoSistema.portaPrincipal !== abrir) togglePorta();
      return abrir ? 'Porta destrancada' : 'Porta trancada';
    }
    case 'definir_janela': {
      const abrir = String(args.estado).startsWith('abert');
      if (estadoSistema.janelaSala !== abrir) toggleJanela();
      return abrir ? 'Janela aberta' : 'Janela fechada';
    }
    case 'abrir_camera': {
      if (typeof abrirCamera !== 'function') return null; // só existe na central
      const nome = String(args.nome || '');
      /entrada|porta|frente|webcam|computador/i.test(nome) ? abrirCamera('webcam', 'Entrada principal') : abrirCameraPorNome(nome);
      return `Câmera ${nome} aberta`;
    }
    case 'acionar_emergencia': {
      const servico = args.servico === 'BOMBEIROS' ? 'BOMBEIROS' : 'POLICIA';
      discarEmergencia(servico, args.motivo || 'Pedido pelo assistente');
      return servico === 'POLICIA' ? 'Polícia acionada (5 s para cancelar)' : 'Bombeiros acionados (5 s para cancelar)';
    }
    default:
      return null;
  }
}

// Mostra no topo se o Llama está configurado.
async function verificarAssistente() {
  const { ok, dados } = await api('/assistente/status').catch(() => ({}));
  const llama = ok && dados.llama;
  document.getElementById('chipIA').dataset.estado = llama ? 'ia' : 'offline';
  document.getElementById('txtIA').textContent = llama ? `Llama · ${dados.modelo}` : 'Llama desligado';
  document.getElementById('assistenteModo').textContent = !ok ? 'servidor fora do ar'
    : llama ? `IA Llama (${dados.modelo}) pelo Ollama` : 'configure o Ollama no .env';
  document.getElementById('assistente').classList.toggle('com-ia', Boolean(llama));
}

window.addEventListener('DOMContentLoaded', () => {
  if (!getSession()) return;
  adicionarMensagemChat(`Olá, ${getSession().name.split(' ')[0]}! Sou o assistente do Sentinel. Pergunte como está a casa ou peça uma ação.`, 'system-msg');
  verificarAssistente();
});
