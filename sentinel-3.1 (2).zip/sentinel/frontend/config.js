// Endereço da API. Aberto pelo próprio servidor (3001/3443) ou publicado na
// internet: mesma origem. Aberto pelo Live Server ou arquivo: aponta para :3001.
(function () {
  const { protocol, hostname, port, origin } = location;
  const mesmaOrigem = ['3001', '3443', ''].includes(port) && protocol.startsWith('http');
  const base = mesmaOrigem ? origin : `http://${hostname || 'localhost'}:3001`;
  window.SENTINEL = { origem: base, api: `${base}/api` };
})();
