import { Router } from 'express';
import { pool } from '../db';
import { avisarPaineis } from '../tempoReal';

// ==========================================================
// EVENTOS (Gabriel) — mesmas rotas da versão 2.1.
// Antes os logs ficavam numa lista na memória; agora ficam no MySQL.
// ==========================================================
const router = Router();

/**
 * @swagger
 * /api/status:
 *   get:
 *     summary: Status do sistema e os últimos 50 eventos
 *     tags: [Eventos]
 */
router.get('/status', async (_req, res) => {
  try {
    const [logs] = await pool.query('SELECT id, tipo, status, criado_em AS timestamp FROM eventos ORDER BY id DESC LIMIT 50');
    const [[{ total }]]: any = await pool.query('SELECT COUNT(*) AS total FROM eventos');
    res.json({ status: 'Operacional', conexao: 'Estável', totalLogs: total, logs });
  } catch {
    res.status(500).json({ status: 'Sem banco', conexao: 'Instável', totalLogs: 0, logs: [] });
  }
});

/**
 * @swagger
 * /api/evento:
 *   post:
 *     summary: Registra um evento da casa (sensor, câmera, assistente...)
 *     tags: [Eventos]
 *     requestBody:
 *       content:
 *         application/json:
 *           example: { "tipo": "Porta Principal", "status": "ABERTA" }
 *     responses:
 *       201: { description: Evento registrado }
 */
router.post('/evento', async (req, res) => {
  const { tipo = 'Geral', status = 'Atualizado' } = req.body;
  try {
    const [resultado]: any = await pool.query('INSERT INTO eventos (tipo, status) VALUES (?, ?)', [tipo, status]);
    const novoLog = { id: resultado.insertId, tipo, status, timestamp: new Date().toISOString() };
    avisarPaineis('evento:novo', novoLog);
    res.status(201).json({ mensagem: 'Evento registrado com sucesso no Back-End', log: novoLog });
  } catch {
    res.status(500).json({ erro: 'Erro no banco de dados.' });
  }
});

export default router;
