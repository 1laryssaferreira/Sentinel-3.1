-- ==========================================================
-- SENTINEL — banco de dados (MySQL)
-- Rode com: npm run migrate
-- ==========================================================
CREATE DATABASE IF NOT EXISTS sentinel_db
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sentinel_db;

-- Contas de acesso. papel = 'Administrador' (central) ou 'Usuário' (tela do morador)
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  papel VARCHAR(40) NOT NULL DEFAULT 'Usuário',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Biometria facial (Davi): o rosto de cada morador como vetor de 128 números
CREATE TABLE IF NOT EXISTS biometria (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  descriptor JSON NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Cada vez que a câmera reconhece (ou não) alguém
CREATE TABLE IF NOT EXISTS acessos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  biometria_id INT NULL,
  resultado ENUM('LIBERADO','NEGADO','PROCURADO') NOT NULL,
  camera VARCHAR(80) NOT NULL DEFAULT 'Câmera',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_acessos_biometria FOREIGN KEY (biometria_id)
    REFERENCES biometria(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Histórico de eventos (Gabriel): sensores, câmeras, assistente...
CREATE TABLE IF NOT EXISTS eventos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipo VARCHAR(80) NOT NULL,
  status VARCHAR(200) NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Chamadas de emergência SIMULADAS (nenhuma ligação real é feita)
CREATE TABLE IF NOT EXISTS acionamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  servico ENUM('POLICIA','BOMBEIROS') NOT NULL,
  motivo VARCHAR(200) NOT NULL,
  risco_no_momento INT NOT NULL DEFAULT 0,
  automatico TINYINT(1) NOT NULL DEFAULT 0,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
