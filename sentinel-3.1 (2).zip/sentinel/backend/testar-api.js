// ==========================================================
// TESTE AUTOMATIZADO DA BIOMETRIA (Davi)
// Rode com o servidor ligado:  npm test
// ==========================================================
const API = 'http://localhost:3001/api/biometria';

async function post(rota, corpo) {
  const resposta = await fetch(`${API}${rota}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(corpo)
  });
  return { codigo: resposta.status, dados: await resposta.json() };
}

async function executarTeste() {
  console.log('🔄 1. Cadastrando o rosto do morador...');
  // Vetor fictício de 128 pontos representando o rosto do morador
  const vetorMorador = Array.from({ length: 128 }, () => Math.random() * 0.1);
  console.log(await post('/treinar', { nome: 'Davi (Morador de teste)', descriptor: vetorMorador }));

  console.log('\n🔄 2. Autenticando com o MESMO rosto (deve LIBERAR)...');
  const teste1 = await post('/autenticar', { descriptorLeitura: vetorMorador, camera: 'Teste', registrar: false });
  console.log(teste1);

  console.log('\n🔄 3. Autenticando com um rosto DESCONHECIDO (deve NEGAR)...');
  const vetorIntruso = Array.from({ length: 128 }, () => Math.random() + 0.8);
  const teste2 = await post('/autenticar', { descriptorLeitura: vetorIntruso, camera: 'Teste', registrar: false });
  console.log(teste2);

  const passou = teste1.dados.status === 'LIBERADO' && teste2.dados.status === 'NEGADO';
  console.log(passou ? '\n✅ Biometria funcionando: liberou o morador e negou o intruso.' : '\n❌ Algo deu errado no teste.');
}

executarTeste().catch(erro => console.error('❌ O servidor está rodando? (npm run dev)', erro.message));
