import os from 'os';
import { Router } from 'express';

const router = Router();

/**
 * @swagger
 * /api/rede:
 *   get:
 *     summary: IPs deste computador, para o QR Code do celular
 *     tags: [Casa]
 */
router.get('/rede', (_req, res) => {
  const ips = Object.values(os.networkInterfaces()).flat()
    .filter(info => info && info.family === 'IPv4' && !info.internal)
    .map(info => info!.address)
    .sort((a, b) => Number(b.startsWith('192.168.')) - Number(a.startsWith('192.168.')));
  res.json({
    ips,
    portaHttp: Number(process.env.PORT) || 3001,
    portaHttps: process.env.HTTPS === 'true' ? Number(process.env.HTTPS_PORT) || 3443 : null
  });
});

export default router;
