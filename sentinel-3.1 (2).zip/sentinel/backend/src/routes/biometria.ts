import { Router } from 'express';
import { pool } from '../db';
import { avisarPaineis } from '../tempoReal';

// ==========================================================
// MOTOR DE BIOMETRIA (Davi)
// A câmera transforma o rosto em 128 números (face-api.js).
// Aqui comparamos esses números com os moradores do MySQL.
// ==========================================================
const router = Router();

// 3. Função de Validação Biométrica: quanto menor a distância, mais parecidos os rostos.
function calcularDistanciaEuclidiana(vetorA: number[], vetorB: number[]) {
  let soma = 0;
  for (let i = 0; i < vetorA.length; i++) {
    const a = vetorA[i] ?? 0;
    const b = vetorB[i] ?? 0;
    soma += Math.pow(a - b, 2);
  }
  return Math.sqrt(soma);
}

const LIMITE_DE_TOLERANCIA = 0.5;

/**
 * @swagger
 * /api/biometria/treinar:
 *   post:
 *     summary: Cadastra a biometria facial de um morador no MySQL
 *     tags: [Biometria]
 *     requestBody:
 *       content:
 *         application/json:
 *           example: { "nome": "Davi (Morador)", "descriptor": [0.01, 0.02, "... 128 números"] }
 *     responses:
 *       201: { description: Biometria salva }
 *       400: { description: O vetor precisa ter 128 pontos }
 */
router.post('/treinar', async (req, res) => {
  const { nome, descriptor } = req.body;

  if (!nome || !Array.isArray(descriptor) || descriptor.length !== 128) {
    return res.status(400).json({ erro: 'Dados inválidos. O vetor deve ter 128 pontos.' });
  }

  try {
    await pool.execute('INSERT INTO biometria (nome, descriptor) VALUES (?, ?)', [nome, JSON.stringify(descriptor)]);
    console.log(`[LOG] Novo morador salvo no banco: ${nome}`);
    avisarPaineis('morador:novo', { nome });
    res.status(201).json({ mensagem: `Biometria de ${nome} salva no cofre com sucesso!` });
  } catch (erro) {
    console.error('Erro MySQL:', erro);
    res.status(500).json({ erro: 'Erro ao salvar no banco de dados.' });
  }
});

/**
 * @swagger
 * /api/biometria/autenticar:
 *   post:
 *     summary: Compara o rosto lido pela câmera com todos os moradores do banco
 *     tags: [Biometria]
 *     requestBody:
 *       content:
 *         application/json:
 *           example: { "descriptorLeitura": [0.01, 0.02, "... 128 números"], "camera": "Entrada principal", "registrar": true }
 *     responses:
 *       200: { description: LIBERADO — morador reconhecido }
 *       403: { description: NEGADO — rosto desconhecido }
 */
router.post('/autenticar', async (req, res) => {
  const { descriptorLeitura, camera = 'Câmera', registrar = true } = req.body;

  if (!Array.isArray(descriptorLeitura) || descriptorLeitura.length !== 128) {
    return res.status(400).json({ erro: 'Dados inválidos. O vetor deve ter 128 pontos.' });
  }

  try {
    const [rows] = await pool.execute('SELECT id, nome, descriptor FROM biometria');

    let melhorCorrespondencia = { id: 0, nome: 'DESCONHECIDO', distancia: 1.0 };

    // Compara o rosto da câmera com TODOS os rostos do banco MySQL
    for (const usuario of rows as any[]) {
      const descriptorSalvo = typeof usuario.descriptor === 'string' ? JSON.parse(usuario.descriptor) : usuario.descriptor;
      const distancia = calcularDistanciaEuclidiana(descriptorLeitura, descriptorSalvo);
      if (distancia < melhorCorrespondencia.distancia) {
        melhorCorrespondencia = { id: usuario.id, nome: usuario.nome, distancia };
      }
    }

    const liberado = melhorCorrespondencia.distancia < LIMITE_DE_TOLERANCIA;

    // Novidade da integração: cada tentativa fica registrada no histórico de acessos.
    if (registrar) {
      await pool.execute('INSERT INTO acessos (biometria_id, resultado, camera) VALUES (?, ?, ?)',
        [liberado ? melhorCorrespondencia.id : null, liberado ? 'LIBERADO' : 'NEGADO', camera]);
      avisarPaineis('acesso:novo', { resultado: liberado ? 'LIBERADO' : 'NEGADO', nome: liberado ? melhorCorrespondencia.nome : null, camera });
    }

    const distancia = Number(melhorCorrespondencia.distancia.toFixed(3));
    if (liberado) {
      res.json({ status: 'LIBERADO', usuario: melhorCorrespondencia.nome, acao: 'Destrancar porta', distancia });
    } else {
      res.status(403).json({ status: 'NEGADO', alerta: 'CRITICO', acao: 'Manter porta trancada', distancia });
    }
  } catch (erro) {
    console.error('Erro na autenticação:', erro);
    res.status(500).json({ erro: 'Erro ao consultar o banco de dados.' });
  }
});

/**
 * @swagger
 * /api/biometria/moradores:
 *   get:
 *     summary: Lista os moradores cadastrados (sem o vetor do rosto)
 *     tags: [Biometria]
 */
router.get('/moradores', async (_req, res) => {
  try {
    const [linhas] = await pool.query('SELECT id, nome, criado_em FROM biometria ORDER BY nome');
    res.json(linhas);
  } catch {
    res.status(500).json({ erro: 'Erro no banco de dados.' });
  }
});

/**
 * @swagger
 * /api/biometria/moradores/{id}:
 *   delete:
 *     summary: Remove um morador e a biometria dele
 *     tags: [Biometria]
 *     parameters:
 *       - { name: id, in: path, required: true, schema: { type: integer } }
 */
router.delete('/moradores/:id', async (req, res) => {
  await pool.execute('DELETE FROM biometria WHERE id = ?', [Number(req.params.id)]).catch(() => {});
  res.status(204).end();
});

/**
 * @swagger
 * /api/biometria/acessos:
 *   get:
 *     summary: Últimos 20 acessos, com o nome do morador (JOIN entre acessos e biometria)
 *     tags: [Biometria]
 */
router.get('/acessos', async (_req, res) => {
  try {
    const [linhas] = await pool.query(
      `SELECT a.resultado, a.camera, a.criado_em, b.nome
       FROM acessos a LEFT JOIN biometria b ON b.id = a.biometria_id
       ORDER BY a.id DESC LIMIT 20`
    );
    res.json(linhas);
  } catch {
    res.status(500).json({ erro: 'Erro no banco de dados.' });
  }
});

/**
 * @swagger
 * /api/biometria/procurado:
 *   post:
 *     summary: Registra a simulação de uma pessoa procurada pela polícia
 *     tags: [Biometria]
 */
router.post('/procurado', async (req, res) => {
  const camera = req.body?.camera || 'Simulação';
  await pool.execute('INSERT INTO acessos (resultado, camera) VALUES (?, ?)', ['PROCURADO', camera]).catch(() => {});
  avisarPaineis('acesso:novo', { resultado: 'PROCURADO', nome: null, camera });
  res.status(201).json({ status: 'PROCURADO' });
});

export default router;
