import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { pool } from '../db';
import { JWT_SECRET } from '../autenticacao';

const router = Router();
const gerarToken = (usuario: object) => jwt.sign(usuario, JWT_SECRET, { expiresIn: '12h' });

/**
 * @swagger
 * /api/auth/cadastro:
 *   post:
 *     summary: Cria uma conta de usuário (senha guardada com bcrypt)
 *     tags: [Login]
 *     requestBody:
 *       content:
 *         application/json:
 *           example: { "nome": "Maria Silva", "email": "maria@email.com", "senha": "Senha123" }
 *     responses:
 *       201: { description: Conta criada; devolve o usuário e o token }
 *       409: { description: E-mail já cadastrado }
 */
router.post('/cadastro', async (req, res) => {
  const { nome, email, senha } = req.body;
  if (!nome || !email || !senha || senha.length < 8) {
    return res.status(400).json({ erro: 'Preencha nome, e-mail e uma senha de 8 ou mais caracteres.' });
  }
  try {
    const senhaHash = await bcrypt.hash(senha, 10);
    const [resultado]: any = await pool.query(
      'INSERT INTO usuarios (nome, email, senha_hash, papel) VALUES (?, ?, ?, ?)',
      [nome.trim(), email.toLowerCase(), senhaHash, 'Usuário']
    );
    const usuario = { id: resultado.insertId, nome: nome.trim(), email: email.toLowerCase(), papel: 'Usuário' };
    res.status(201).json({ usuario, token: gerarToken(usuario) });
  } catch (erro: any) {
    if (erro.code === 'ER_DUP_ENTRY') return res.status(409).json({ erro: 'Este e-mail já tem conta.' });
    res.status(500).json({ erro: 'Erro no banco de dados.' });
  }
});

/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     summary: Confere e-mail e senha e devolve um token JWT
 *     tags: [Login]
 *     requestBody:
 *       content:
 *         application/json:
 *           example: { "email": "operador@sentinel.com", "senha": "Sentinel123" }
 *     responses:
 *       200: { description: Login certo; devolve o usuário (com o papel) e o token }
 *       401: { description: E-mail ou senha inválidos }
 */
router.post('/login', async (req, res) => {
  const { email, senha } = req.body;
  try {
    const [linhas]: any = await pool.query('SELECT * FROM usuarios WHERE email = ?', [String(email).toLowerCase()]);
    const encontrado = linhas[0];
    if (!encontrado || !(await bcrypt.compare(senha || '', encontrado.senha_hash))) {
      return res.status(401).json({ erro: 'E-mail ou senha inválidos.' });
    }
    const usuario = { id: encontrado.id, nome: encontrado.nome, email: encontrado.email, papel: encontrado.papel };
    res.json({ usuario, token: gerarToken(usuario) });
  } catch {
    res.status(500).json({ erro: 'Erro no banco de dados.' });
  }
});

export default router;
