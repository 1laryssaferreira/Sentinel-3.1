# Sentinel 3.1 — central de segurança residencial

Projeto em grupo de Análise e Desenvolvimento de Sistemas. Junta o protótipo e
a biometria do **Davi** e o front-end e o design do **Gabriel**, integrados
pela **Laryssa**, com melhorias e um assistente com IA (Llama).

> As chamadas para polícia e bombeiros são **simuladas**: nenhuma ligação real
> é feita. O acionamento só fica registrado no banco.

## De quem é cada parte

| Pasta / arquivo | Quem | O que faz |
| --- | --- | --- |
| `frontend/site.html`, Figma | Gabriel | Site de apresentação |
| `frontend/login.html`, `cadastro.html`, `auth.js` | Gabriel | Login e cadastro com dois papéis (administrador e usuário) |
| `frontend/index.html`, `app.js`, `style.css` | Gabriel | Central: motor de risco, sensores, emergência e eventos |
| `frontend/usuario.html`, `usuario.js` | Gabriel | Tela do morador, com histórico filtrado |
| `frontend/biometria.js` | Gabriel + Davi | Câmera, "Memorizar rosto", "Ativar IA" e "Simular procurado" |
| `backend/src/routes/biometria.ts` | Davi | API de biometria: `/treinar` e `/autenticar`, distância euclidiana, limite 0,5 |
| `backend/testar-api.js` | Davi | Teste automatizado da biometria (`npm test`) |
| Swagger (`/api-docs`) | Davi | Documentação de todas as rotas |
| `backend/src/assistente/llama.ts` | Everton | Assistente com Llama e ferramentas (tool calling) |
| `backend/src/routes/assistente.ts` | Everton | Rota do chat: exige login e limita a 20 mensagens por minuto |
| `frontend/assistente.js` | Everton | Tela do chat e execução das ações que o Llama pede |
| `backend/src/server.ts`, `tempoReal.ts`, `routes/` | Laryssa | Integração: servidor único, MySQL, login seguro, tempo real |
| `frontend/cameras.js`, `celular.html` | Laryssa | Celular como câmera (WebRTC + HTTPS) |

## O que mudou em relação às versões do grupo

- **Login de verdade:** a senha agora é conferida no servidor (bcrypt + token JWT), e não mais no `localStorage`. Os papéis da 2.1 continuam.
- **Biometria no MySQL:** o "Ativar IA" do Gabriel agora pergunta à API do Davi, que compara o rosto com **todos** os moradores do banco. Cada acesso fica registrado.
- **Eventos no MySQL:** as rotas `/api/status` e `/api/evento` da 2.1 continuam, mas os eventos são salvos no banco.
- **Assistente com Llama:** a IA conversa em português, consulta o MySQL e age no painel usando ferramentas (tool calling).
- **Tempo real:** a central e a tela do usuário mostram a mesma coisa ao mesmo tempo.
- **Celular como câmera**, protocolo de emergência automático acima de 90% e visual do Figma em todas as telas.

## Como rodar

```bash
cd backend
copy .env.example .env    # Windows; preencha a senha do MySQL
npm install
npm run migrate           # cria o banco e as duas contas de teste
npm run dev
```

- Site: **http://localhost:3001**
- Documentação da API (Swagger): **http://localhost:3001/api-docs**
- Teste da biometria, com o servidor ligado: `npm test`

Contas de teste (senha `Sentinel123`): `operador@sentinel.com` (administrador)
e `usuario@sentinel.com` (usuário).

## Assistente com Llama

1. Instale o Ollama (ollama.com) e rode `ollama pull llama3.1`.
2. No `.env`, deixe `OLLAMA_URL=http://localhost:11434` e `OLLAMA_MODEL=llama3.1`.

O Llama recebe a conversa e o estado da casa, e tem 8 ferramentas:

| Tipo | Ferramentas | Quem executa |
| --- | --- | --- |
| Ação no painel | trancar/destrancar a porta, abrir/fechar a janela, abrir uma câmera, acionar emergência | o painel, no navegador |
| Consulta ao banco | eventos, acessos, moradores e emergências | o servidor, no MySQL |

Ele pode usar ferramentas até 4 vezes por mensagem antes de responder. Cada
ação feita aparece como um selo verde embaixo da resposta. Emergências abrem o
alerta com 5 segundos para cancelar. Com o Ollama fechado, o chat avisa que o
Llama não respondeu.

## Câmera do celular

Com `HTTPS=true` no `.env`, clique em **Conectar celular** na central e
escaneie o QR Code (celular e PC no mesmo Wi-Fi). No aviso de segurança, toque
em *Avançado → Continuar*. Se não abrir, libere o firewall (PowerShell como
administrador):

```powershell
New-NetFirewallRule -DisplayName "Sentinel" -Direction Inbound -Protocol TCP -LocalPort 3001,3443 -Action Allow
```

## Banco de dados (sentinel_db)

| Tabela | Guarda |
| --- | --- |
| usuarios | contas, senha com bcrypt e papel |
| biometria | moradores e o vetor de 128 números do rosto (tabela do Davi) |
| acessos | cada rosto liberado, negado ou procurado (chave estrangeira para biometria) |
| eventos | histórico da casa |
| acionamentos | emergências simuladas |

A IA de rosto (face-api.js 0.22.2) e os modelos ficam em `frontend/vendor`,
então o reconhecimento funciona mesmo sem internet.
