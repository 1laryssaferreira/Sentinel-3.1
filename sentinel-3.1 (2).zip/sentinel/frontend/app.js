// ==========================================================
// SENTINEL — núcleo do painel (Gabriel)
// Mesmas funções da versão 2.1: estado da casa, motor de risco,
// sensores, emergência e ligação com o back-end.
// Usado pelas duas telas: central (index.html) e usuário (usuario.html).
// ==========================================================

// ESTADO GLOBAL DO SISTEMA
let estadoSistema = {
  portaPrincipal: false,     // true = aberta
  janelaSala: false,         // true = aberta
  incendioDetectado: false,
  gasDetectado: false,
  alertaPolicial: false
};

// BANCO DE DADOS SIMULADO DA POLÍCIA
const bancoDadosPolicia = [
  { id: 'PROC-8832', nome: 'Carlos "Sombra" Mendes', mandado: 'Ativo - Art. 157', periculosidade: 'ALTA' }
];

const ehCentral = () => document.body.dataset.pagina === 'administrador';
const $ = (id) => document.getElementById(id);
const hora = (d = new Date()) => d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
let ultimoRisco = 10;

function aviso(texto, tom = 'info') {
  const el = document.createElement('div');
  el.className = 'aviso';
  el.dataset.tom = tom;
  el.textContent = texto;
  $('avisos')?.appendChild(el);
  setTimeout(() => el.remove(), 4500);
}

// ==========================================
// 🛡️ 1. MOTOR PREDITIVO DE RISCO
// ==========================================
function recalcularRisco() {
  let scoreRisco = 10;

  if (estadoSistema.portaPrincipal) scoreRisco += 25;
  if (estadoSistema.janelaSala) scoreRisco += 20;
  if (estadoSistema.gasDetectado) scoreRisco += 50;
  if (estadoSistema.incendioDetectado) scoreRisco += 70;
  if (estadoSistema.alertaPolicial) scoreRisco += 90;

  if (scoreRisco > 100) scoreRisco = 100;

  atualizarUI(scoreRisco);

  // Protocolo automático (só na central, para não acionar duas vezes):
  // a partir de 90% o Sentinel chama o serviço certo sozinho.
  if (ehCentral() && scoreRisco >= 90 && ultimoRisco < 90) {
    const servico = estadoSistema.incendioDetectado || estadoSistema.gasDetectado ? 'BOMBEIROS' : 'POLICIA';
    discarEmergencia(servico, `Protocolo automático: risco de ${scoreRisco}%`, true);
  }
  ultimoRisco = scoreRisco;
  return scoreRisco;
}

function atualizarUI(score) {
  const nivel = score < 30 ? ['baixo', 'Risco baixo'] : score < 70 ? ['medio', 'Risco moderado'] : ['alto', 'Risco alto'];
  $('chipRisco').dataset.nivel = nivel[0];
  $('riskLevel').textContent = nivel[1];
  $('riskValue').textContent = `${score}%`;
  $('medidor').style.setProperty('--risco', score);

  const alertas = [
    estadoSistema.alertaPolicial && 'pessoa procurada na câmera',
    estadoSistema.incendioDetectado && 'fumaça na cozinha',
    estadoSistema.gasDetectado && 'vazamento de gás',
    estadoSistema.portaPrincipal && 'porta principal aberta',
    estadoSistema.janelaSala && 'janela da sala aberta'
  ].filter(Boolean);
  if ($('riscoExplica')) {
    $('riscoExplica').textContent = alertas.length
      ? alertas.join(', ').replace(/^./, c => c.toUpperCase()) + '.'
      : 'Portas e janelas fechadas, sensores sem alerta.';
  }
}

// ==========================================
// 🚪 2. SENSORES DA CASA
// ==========================================
const SENSORES = {
  portaPrincipal: { nome: 'Porta Principal', ligado: 'ABERTA', desligado: 'TRANCADA' },
  janelaSala: { nome: 'Janela da Sala', ligado: 'ABERTA', desligado: 'FECHADA' },
  incendioDetectado: { nome: 'Sensor de Fumaça', ligado: 'FUMAÇA DETECTADA', desligado: 'NORMAL', perigo: true },
  gasDetectado: { nome: 'Sensor de Gás', ligado: 'VAZAMENTO', desligado: 'NORMAL', perigo: true }
};

// Pinta cada sensor na lista e na planta. Ativo = vermelho (classe "alerta").
function atualizarSensores() {
  for (const [campo, sensor] of Object.entries(SENSORES)) {
    const ativo = estadoSistema[campo];
    const item = document.querySelector(`#listaSensores li[data-sensor="${campo}"]`);
    if (item) {
      item.className = ativo ? (sensor.perigo ? 'alerta' : 'atencao') : '';
      const texto = (ativo ? sensor.ligado : sensor.desligado).toLowerCase();
      item.querySelector('.s-estado').textContent = texto[0].toUpperCase() + texto.slice(1);
    }
    document.querySelectorAll(`.disp[data-sensor="${campo}"]`).forEach(b => b.classList.toggle('alerta', ativo));
  }
  $('comodoCozinha')?.classList.toggle('perigo', estadoSistema.incendioDetectado || estadoSistema.gasDetectado);
  $('comodoSala')?.classList.toggle('atencao', estadoSistema.janelaSala);
}

// Muda um sensor, avisa o servidor (que avisa as outras telas) e recalcula o risco.
function definirSensor(campo, valor, sincronizar = true) {
  if (estadoSistema[campo] === valor) return;
  estadoSistema[campo] = valor;
  atualizarSensores();
  if (sincronizar) {
    api(`/casa/${campo}`, { method: 'PUT', body: { ativo: valor } }).catch(() => {});
    if (SENSORES[campo]) enviarEventoBackend(SENSORES[campo].nome, valor ? SENSORES[campo].ligado : SENSORES[campo].desligado);
  }
  recalcularRisco();
}

function togglePorta() { definirSensor('portaPrincipal', !estadoSistema.portaPrincipal); }
function toggleJanela() { definirSensor('janelaSala', !estadoSistema.janelaSala); }
function toggleIncendio() { definirSensor('incendioDetectado', !estadoSistema.incendioDetectado); }
function toggleGas() { definirSensor('gasDetectado', !estadoSistema.gasDetectado); }

// Pessoa com mandado de prisão aparece na câmera: risco vai a 100% por 30 segundos.
function simularProcuradoPolicia() {
  const procurado = bancoDadosPolicia[0];
  if ($('scanStatus')) { $('scanStatus').textContent = `PROCURADO: ${procurado.nome}`; $('scanStatus').dataset.tom = 'perigo'; }
  if ($('lastAccess')) $('lastAccess').textContent = `Alerta policial (${procurado.id})`;
  api('/biometria/procurado', { method: 'POST', body: { camera: $('modalTitle')?.textContent || 'Simulação' } }).catch(() => {});
  enviarEventoBackend('Alerta Policial', `PROCURADO DETECTADO: ${procurado.nome}`);
  definirSensor('alertaPolicial', true);
  setTimeout(() => definirSensor('alertaPolicial', false), 30000);
}

// ==========================================
// 🚨 3. EMERGÊNCIA (SIMULADA)
// ==========================================
const SERVICOS = { POLICIA: ['190', 'Polícia Militar'], BOMBEIROS: ['193', 'Corpo de Bombeiros'] };
let timerEmergencia = null;
let emergenciaConectada = false;

// Mostra o alerta com 5 segundos para cancelar. Se não cancelar, registra no banco.
function discarEmergencia(servico, motivo, automatico = false) {
  const [numero, nome] = SERVICOS[servico];
  clearInterval(timerEmergencia);
  emergenciaConectada = false;
  $('emergencyModal').hidden = false;
  $('emergencyModal').classList.remove('conectada');
  $('emergencyTitle').textContent = `Alerta simulado · ${numero} (${nome})`;
  $('emergencyBody').textContent = `Cenário: ${motivo}. Cancele se for engano.`;
  $('btnCancelarEmergencia').textContent = 'Cancelar acionamento';

  let segundos = 5;
  $('emergencyTimer').textContent = `00:0${segundos}`;
  timerEmergencia = setInterval(() => {
    segundos--;
    $('emergencyTimer').textContent = `00:0${segundos}`;
    if (segundos > 0) return;
    clearInterval(timerEmergencia);
    emergenciaConectada = true;
    $('emergencyModal').classList.add('conectada');
    $('emergencyTimer').textContent = 'Em linha';
    $('emergencyTitle').textContent = `${nome} na linha · ${numero}`;
    $('emergencyBody').textContent = 'Demonstração: nenhuma ligação real foi feita. O acionamento ficou registrado no banco.';
    $('btnCancelarEmergencia').textContent = 'Encerrar simulação';
    api('/emergencia', { method: 'POST', body: { servico, motivo, risco: ultimoRisco, automatico } }).catch(() => {});
    enviarEventoBackend('Emergência', `Chamada simulada para ${numero}: ${motivo}`);
  }, 1000);
}

function cancelarEmergencia() {
  clearInterval(timerEmergencia);
  if (!emergenciaConectada) enviarEventoBackend('Emergência', 'Acionamento cancelado pelo usuário');
  $('emergencyModal').hidden = true;
}

// ==========================================
// 📡 4. HISTÓRICO E LIGAÇÃO COM O BACK-END
// ==========================================
const backendLogsRenderizados = new Set();
let totalLogsBanco = 0;

function tomDoEvento(texto) {
  if (/fuma|vazamento|procurad|emerg|negad|190|193/i.test(texto)) return 'perigo';
  if (/aberta|desconhecid|cancelad/i.test(texto)) return 'atencao';
  if (/trancada|fechada|normal|autorizad|liberad|cadastrad|conectad/i.test(texto)) return 'ok';
  return '';
}

function adicionarLog(tipo, status, quando = new Date()) {
  const lista = $('logFeed');
  if (!lista) return;
  const item = document.createElement('li');
  item.dataset.tom = tomDoEvento(`${tipo} ${status}`);
  item.dataset.tipo = /câmera|reconhec|acesso|morador|procurad/i.test(tipo) ? 'camera' : 'system';
  item.innerHTML = '<time></time><span><strong></strong> — <em></em></span>';
  item.querySelector('time').textContent = hora(quando);
  item.querySelector('strong').textContent = tipo;
  item.querySelector('em').textContent = status;
  lista.prepend(item);
  if (typeof filtrarHistorico === 'function') filtrarHistorico();
}

function renderizarLogsBackend(logs = []) {
  [...logs].reverse().forEach(log => {
    if (backendLogsRenderizados.has(log.id)) return;
    backendLogsRenderizados.add(log.id);
    if (log.id > totalLogsBanco) atualizarContador(log.id);
    const quando = new Date(String(log.timestamp).replace(' ', 'T'));
    adicionarLog(log.tipo, log.status, isNaN(quando) ? new Date() : quando);
  });
}

function atualizarEstadoBackend(online, totalLogs = null) {
  $('chipServidor').dataset.estado = online ? 'online' : 'offline';
  $('txtServidor').textContent = online ? 'online' : 'fora do ar';
  if (totalLogs !== null) atualizarContador(totalLogs);
}

// Quantos eventos já estão salvos no MySQL.
function atualizarContador(total) {
  totalLogsBanco = Math.max(totalLogsBanco, total);
  if ($('backendEventCount')) $('backendEventCount').textContent = `· ${totalLogsBanco} no banco`;
}

async function verificarBackend() {
  try {
    const { ok, dados } = await api('/status');
    atualizarEstadoBackend(ok, dados?.totalLogs ?? null);
    renderizarLogsBackend(dados?.logs || []);
  } catch {
    atualizarEstadoBackend(false);
  }
}

// Envia o evento ao servidor (que salva no MySQL e avisa as outras telas).
// Sem servidor, o evento aparece só nesta tela.
async function enviarEventoBackend(tipo, status) {
  try {
    const { ok, dados } = await api('/evento', { method: 'POST', body: { tipo, status } });
    if (!ok) throw new Error();
    renderizarLogsBackend([dados.log]);
  } catch {
    adicionarLog(tipo, status);
  }
}

// ==========================================
// ⚡ 5. TEMPO REAL (Socket.IO)
// ==========================================
let socket = null;
const ouvintesSocket = [];
const aoConectarSocket = (fn) => (socket ? fn(socket) : ouvintesSocket.push(fn));

function conectarTempoReal() {
  const script = document.createElement('script');
  script.src = `${window.SENTINEL.origem}/socket.io/socket.io.js`;
  script.onload = () => {
    socket = io(window.SENTINEL.origem);
    socket.on('connect', () => { socket.emit('painel:entrar'); atualizarEstadoBackend(true); });
    socket.on('disconnect', () => atualizarEstadoBackend(false));
    socket.on('evento:novo', (log) => renderizarLogsBackend([log]));
    socket.on('casa:atualizada', (remoto) => Object.keys(estadoSistema).forEach(c => definirSensor(c, Boolean(remoto[c]), false)));
    socket.on('emergencia:nova', ({ servico }) => !ehCentral() && aviso(`Emergência simulada acionada: ${servico === 'POLICIA' ? 'polícia' : 'bombeiros'}.`, 'perigo'));
    ouvintesSocket.forEach(fn => fn(socket));
  };
  document.head.appendChild(script);
}

// O que o assistente recebe sobre a casa a cada mensagem.
function obterEstadoCasa() {
  return {
    ...estadoSistema,
    risco: ultimoRisco,
    cameras: typeof listarCameras === 'function' ? listarCameras() : [],
    moradores: typeof moradoresCadastrados !== 'undefined' ? moradoresCadastrados.map(m => m.nome) : [],
    ultimoAcesso: $('lastAccess')?.textContent || 'nenhum'
  };
}

// Inicialização do painel
window.addEventListener('DOMContentLoaded', async () => {
  if (!getSession()) return;
  const h = new Date().getHours();
  if ($('saudacao')) $('saudacao').textContent = `${h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'}, ${getSession().name.split(' ')[0]}.`;
  atualizarSensores();
  recalcularRisco();
  verificarBackend();
  conectarTempoReal();
  const { ok, dados } = await api('/casa').catch(() => ({}));
  if (ok) Object.keys(estadoSistema).forEach(c => definirSensor(c, Boolean(dados[c]), false));
});
