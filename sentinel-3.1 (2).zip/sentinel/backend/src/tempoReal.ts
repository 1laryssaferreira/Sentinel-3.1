import type { Server } from 'socket.io';

// ==========================================================
// TEMPO REAL (Socket.IO)
// 1. Avisa todos os painéis abertos quando algo acontece.
// 2. Apresenta o celular ao painel para o vídeo (WebRTC).
//    O vídeo vai direto de um aparelho para o outro; aqui só
//    passam os "convites" da conexão.
// ==========================================================
let io: Server | null = null;

export function avisarPaineis(evento: string, dados: unknown) {
  io?.to('paineis').emit(evento, dados);
}

export function iniciarTempoReal(servidor: Server) {
  io = servidor;
  const celulares = new Map<string, string>(); // id da conexão → nome da câmera

  servidor.on('connection', (socket) => {
    socket.on('painel:entrar', () => {
      socket.join('paineis');
      for (const [socketId, nome] of celulares) socket.emit('camera:nova', { socketId, nome });
    });

    socket.on('camera:entrar', ({ nome }: { nome: string }) => {
      const nomeLimpo = String(nome || 'Celular').slice(0, 40);
      celulares.set(socket.id, nomeLimpo);
      avisarPaineis('camera:nova', { socketId: socket.id, nome: nomeLimpo });
    });

    for (const tipo of ['sinal:offer', 'sinal:answer', 'sinal:ice']) {
      socket.on(tipo, ({ para, dados }: { para: string; dados: unknown }) => {
        servidor.to(para).emit(tipo, { de: socket.id, dados });
      });
    }

    socket.on('disconnect', () => {
      if (celulares.delete(socket.id)) avisarPaineis('camera:saiu', { socketId: socket.id });
      else servidor.emit('painel:saiu', { socketId: socket.id });
    });
  });
}
