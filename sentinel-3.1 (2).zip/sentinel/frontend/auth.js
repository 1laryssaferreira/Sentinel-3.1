// ==========================================================
// LOGIN, CADASTRO E SESSÃO (Gabriel)
// Mesmas funções da versão 2.1. A diferença: antes as contas
// ficavam no localStorage; agora o servidor confere a senha no
// MySQL (bcrypt) e devolve um token JWT que guardamos aqui.
// ==========================================================
const SENTINEL_SESSION_KEY = 'sentinel_session_v3';

// Administrador vai para a central; usuário vai para a tela do morador.
function getDashboardForRole(role) {
  return String(role || '').toLowerCase() === 'administrador' ? 'index.html' : 'usuario.html';
}

function setSession(usuario, token) {
  const session = { name: usuario.nome, email: usuario.email, role: usuario.papel, token };
  localStorage.setItem(SENTINEL_SESSION_KEY, JSON.stringify(session));
  return session;
}

function getSession() {
  try {
    const session = JSON.parse(localStorage.getItem(SENTINEL_SESSION_KEY));
    const validade = JSON.parse(atob(session.token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).exp;
    return validade * 1000 > Date.now() ? session : null; // token vencido = deslogado
  } catch {
    return null;
  }
}

function logoutSentinel() {
  localStorage.removeItem(SENTINEL_SESSION_KEY);
  window.location.href = 'login.html';
}

// Atalho para chamar a API já com o token. Devolve { ok, status, dados }.
async function api(caminho, opcoes = {}) {
  const resposta = await fetch(`${window.SENTINEL.api}${caminho}`, {
    method: opcoes.method || 'GET',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getSession()?.token || ''}` },
    body: opcoes.body ? JSON.stringify(opcoes.body) : undefined
  });
  const dados = resposta.status === 204 ? null : await resposta.json().catch(() => null);
  return { ok: resposta.ok, status: resposta.status, dados };
}

function setFeedback(element, message, type = 'error') {
  element.textContent = message;
  element.className = `form-feedback ${type}`;
  element.hidden = false;
}

function clearFeedback(element) {
  element.hidden = true;
}

function togglePassword(inputId, button) {
  const input = document.getElementById(inputId);
  const showing = input.type === 'text';
  input.type = showing ? 'password' : 'text';
  button.textContent = showing ? 'Mostrar' : 'Ocultar';
}

function handleLogin() {
  const form = document.getElementById('loginForm');
  if (!form) return;
  const feedback = document.getElementById('loginFeedback');
  const email = document.getElementById('email');
  const password = document.getElementById('password');

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    clearFeedback(feedback);
    if (!email.value || !password.value) return setFeedback(feedback, 'Preencha seu e-mail e sua senha.');

    try {
      const { ok, dados } = await api('/auth/login', { method: 'POST', body: { email: email.value.trim(), senha: password.value } });
      if (!ok) return setFeedback(feedback, dados?.erro || 'Não foi possível entrar.');
      setSession(dados.usuario, dados.token);
      window.location.href = getDashboardForRole(dados.usuario.papel);
    } catch {
      setFeedback(feedback, 'O servidor não respondeu. Rode "npm run dev" na pasta backend.');
    }
  });

  document.getElementById('fillDemo')?.addEventListener('click', () => { email.value = 'operador@sentinel.com'; password.value = 'Sentinel123'; });
  document.getElementById('fillDemoUser')?.addEventListener('click', () => { email.value = 'usuario@sentinel.com'; password.value = 'Sentinel123'; });
  document.getElementById('esqueciSenha')?.addEventListener('click', () =>
    setFeedback(feedback, 'A troca de senha é feita pelo administrador. Para testar, use uma conta de teste abaixo.', 'info'));
}

function handleRegister() {
  const form = document.getElementById('registerForm');
  if (!form) return;
  const feedback = document.getElementById('registerFeedback');
  const password = document.getElementById('password');
  const strengthBar = document.getElementById('passwordStrength');

  // Medidor de força: +1 ponto para tamanho, maiúscula, número e símbolo.
  password.addEventListener('input', () => {
    const v = password.value;
    const score = [v.length >= 8, /[A-Z]/.test(v), /[0-9]/.test(v), /[^A-Za-z0-9]/.test(v)].filter(Boolean).length;
    strengthBar.dataset.level = score;
    strengthBar.style.width = ['8%', '25%', '50%', '75%', '100%'][score];
    document.getElementById('passwordStrengthLabel').textContent = ['Muito fraca', 'Fraca', 'Média', 'Forte', 'Muito forte'][score];
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    clearFeedback(feedback);
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (name.length < 3) return setFeedback(feedback, 'Digite seu nome completo.');
    if (password.value.length < 8 || !/[A-Z]/.test(password.value) || !/[0-9]/.test(password.value)) {
      return setFeedback(feedback, 'A senha precisa ter 8 caracteres, uma letra maiúscula e um número.');
    }
    if (password.value !== confirmPassword) return setFeedback(feedback, 'As senhas não coincidem.');
    if (!document.getElementById('terms').checked) return setFeedback(feedback, 'Aceite os termos de uso para continuar.');

    try {
      const { ok, dados } = await api('/auth/cadastro', { method: 'POST', body: { nome: name, email, senha: password.value } });
      if (!ok) return setFeedback(feedback, dados?.erro || 'Não foi possível criar a conta.');
      setSession(dados.usuario, dados.token);
      window.location.href = getDashboardForRole(dados.usuario.papel);
    } catch {
      setFeedback(feedback, 'O servidor não respondeu. Rode "npm run dev" na pasta backend.');
    }
  });
}

// Sem sessão, volta para o login. Usuário comum não entra na central do administrador.
function protectDashboard() {
  const pagina = document.body.dataset.pagina;
  const session = getSession();
  if (!pagina) {
    if (session && document.body.classList.contains('auth-page')) window.location.href = getDashboardForRole(session.role);
    return;
  }
  if (!session) return window.location.replace('login.html');
  if (pagina === 'administrador' && session.role !== 'Administrador') return window.location.replace('usuario.html');

  document.querySelectorAll('#userName').forEach(el => { el.textContent = session.name; });
  document.querySelectorAll('#userRole').forEach(el => { el.textContent = session.role; });
  const avatar = document.getElementById('userAvatar');
  if (avatar) avatar.textContent = session.name.split(' ').slice(0, 2).map(p => p[0]).join('').toUpperCase();
}

document.addEventListener('DOMContentLoaded', () => {
  protectDashboard();
  handleLogin();
  handleRegister();
});
