import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import http from 'http';
import https from 'https';
import express from 'express';
import cors from 'cors';
import swaggerUi from 'swagger-ui-express';
import swaggerJsdoc from 'swagger-jsdoc';
import { Server } from 'socket.io';
import { testarConexaoBanco } from './db';
import { iniciarTempoReal } from './tempoReal';
import { configuracaoLlama } from './assistente/llama';
import authRoutes from './routes/auth';
import biometriaRoutes from './routes/biometria';
import eventosRoutes from './routes/eventos';
import casaRoutes from './routes/casa';
import assistenteRoutes from './routes/assistente';
import redeRoutes from './routes/rede';

const app = express();
const PORT = Number(process.env.PORT) || 3001;
const HTTPS_PORT = Number(process.env.HTTPS_PORT) || 3443;
const PASTA_FRONTEND = path.join(__dirname, '..', '..', 'frontend');

app.use(cors());
app.use(express.json({ limit: '1mb' }));

// 1. Site e painel: o próprio servidor entrega o front-end
app.get('/', (_req, res) => res.sendFile(path.join(PASTA_FRONTEND, 'site.html')));
app.use(express.static(PASTA_FRONTEND));

// 2. Configuração do Swagger (documentação em /api-docs)
const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'API Sentinel 3.1 - Smart Home Intelligence',
      version: '3.1.0',
      description: 'Biometria facial, eventos da casa, emergência simulada e assistente com Llama.'
    },
    servers: [{ url: `http://localhost:${PORT}` }]
  },
  apis: [path.join(__dirname, 'routes', '*.{ts,js}')]
};
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerJsdoc(options)));

// 3. Rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/biometria', biometriaRoutes);
app.use('/api', eventosRoutes);
app.use('/api', casaRoutes);
app.use('/api', assistenteRoutes);
app.use('/api', redeRoutes);

// 4. HTTPS: o celular só libera a câmera em página segura.
// Com HTTPS=true, o servidor gera um certificado próprio e sobe também na porta 3443.
async function criarServidorHttps(): Promise<https.Server | null> {
  if (process.env.HTTPS !== 'true') return null;
  const pasta = path.join(__dirname, '..', 'certs');
  const chave = path.join(pasta, 'chave.pem');
  const cert = path.join(pasta, 'cert.pem');
  if (!fs.existsSync(chave)) {
    const gerado = await require('selfsigned').generate([{ name: 'commonName', value: 'sentinel.local' }], { days: 825, keySize: 2048 });
    fs.mkdirSync(pasta, { recursive: true });
    fs.writeFileSync(chave, gerado.private);
    fs.writeFileSync(cert, gerado.cert);
  }
  return https.createServer({ key: fs.readFileSync(chave), cert: fs.readFileSync(cert) }, app);
}

async function iniciar() {
  const servidorHttp = http.createServer(app);
  const servidorHttps = await criarServidorHttps();

  const io = new Server({ cors: { origin: '*' } });
  io.attach(servidorHttp);
  if (servidorHttps) io.attach(servidorHttps);
  iniciarTempoReal(io);

  servidorHttp.listen(PORT, () => {
    console.log(`🛡️  Sentinel rodando em  http://localhost:${PORT}`);
    console.log(`📄 Swagger disponível em: http://localhost:${PORT}/api-docs`);
  });
  servidorHttps?.listen(HTTPS_PORT, () => console.log(`🔐 HTTPS (câmera do celular): https://<ip-do-pc>:${HTTPS_PORT}`));

  const llama = configuracaoLlama();
  console.log(`🧠 Assistente: ${llama.ativa ? `Llama (${llama.modelo}) pelo Ollama` : 'Llama não configurado no .env (modo básico)'}`);
  testarConexaoBanco();
}

iniciar();
