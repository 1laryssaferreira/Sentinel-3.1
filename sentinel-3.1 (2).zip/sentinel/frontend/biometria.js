// ==========================================================
// CÂMERA E RECONHECIMENTO FACIAL (Gabriel + Davi)
// Gabriel: a câmera, os botões e as reações na tela.
// Davi: a API que compara o rosto com os moradores do MySQL.
//
// face-api.js (rede neural no navegador) transforma o rosto em
// 128 números; esses números vão para /api/biometria.
// ==========================================================
// Mesmos modelos que o Davi usava no protótipo
const MODEL_URL = 'vendor/modelos'; // modelos dentro do projeto: funciona sem internet
let modelosCarregados = false;
let streamWebcam = null;          // webcam deste computador
let cameraAberta = null;          // { id, nome }
let intervaloReconhecimento = null;
let descriptorPendente = null;    // rosto esperando o nome no "Memorizar rosto"
let ultimoRegistro = { chave: '', quando: 0 };
let timerPorta = null;
let moradoresCadastrados = [];
let analisando = false;
let ultimoRostoVisto = 0;

function status(texto, tom = '') {
  $('scanStatus').textContent = texto;
  $('scanStatus').dataset.tom = tom;
}

// Carregar Modelos da face-api.js (detector de rosto, pontos do rosto e reconhecimento)
async function carregarModelosIA() {
  for (let i = 0; i < 40 && typeof faceapi === 'undefined'; i++) await new Promise(r => setTimeout(r, 250));
  try {
    await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
    await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
    await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
    modelosCarregados = true;
    console.log('🧠 Modelos de IA carregados');
  } catch (erro) {
    console.error('Erro ao carregar modelos de IA:', erro);
  }
}

const lerRosto = () => faceapi.detectSingleFace($('webcam'), new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceDescriptor();

// ---------------- abrir e fechar a câmera ----------------
async function abrirCamera(id, nome) {
  cameraAberta = { id, nome };
  $('modalTitle').textContent = nome;
  $('modalOrigem').textContent = id === 'webcam' ? 'Webcam do computador' : 'Câmera do celular';
  $('cameraModal').hidden = false;
  $('fundoCamera').hidden = false;
  status('Abrindo câmera…');

  if (id === 'webcam') {
    try {
      streamWebcam = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 1280 } }, audio: false });
      $('webcam').srcObject = streamWebcam;
      enviarEventoBackend('Câmeras', `Câmera "${nome}" aberta`);
    } catch {
      status('Permissão da câmera negada ou câmera em uso.', 'perigo');
      return;
    }
  } else {
    $('webcam').srcObject = camerasCelular.get(id)?.stream || null;
  }
  status(modelosCarregados ? 'Câmera pronta. Memorize um rosto ou ative a IA.' : 'Carregando a IA de rosto…');
}

// Clicar numa câmera da planta: abre a do celular com esse nome, ou oferece conectar uma.
function abrirCameraPorNome(nome) {
  const celular = [...camerasCelular.entries()].find(([, c]) => c.nome.toLowerCase().includes(nome.toLowerCase()));
  celular ? abrirCamera(celular[0], celular[1].nome) : abrirDialogoCelular();
}

function fecharCamera() {
  pararReconhecimento();
  streamWebcam?.getTracks().forEach(track => track.stop());
  streamWebcam = null;
  $('webcam').srcObject = null;
  $('cameraModal').hidden = true;
  $('fundoCamera').hidden = true;
  cameraAberta = null;
}

document.addEventListener('keydown', (e) => e.key === 'Escape' && !$('cameraModal').hidden && fecharCamera());

// ---------------- Memorizar rosto (cadastro no MySQL) ----------------
async function cadastrarBiometria() {
  if (!modelosCarregados) return status('A IA de rosto ainda está carregando…', 'atencao');
  status('Analisando rosto…');
  const deteccao = await lerRosto();
  if (!deteccao) return status('Rosto não detectado. Olhe para a câmera, com luz no rosto.', 'atencao');

  descriptorPendente = Array.from(deteccao.descriptor);
  const b = deteccao.detection.box;
  $('previaRosto').getContext('2d').drawImage($('webcam'), b.x - b.width * 0.3, b.y - b.height * 0.3, b.width * 1.6, b.height * 1.6, 0, 0, 160, 160);
  $('inpNomeMorador').value = '';
  $('dlgMorador').showModal();
  status('Rosto lido. Digite o nome do morador.');
}

async function salvarMorador(event) {
  if (event.submitter?.value !== 'ok') return;
  const nome = $('inpNomeMorador').value.trim();
  const { ok, dados } = await api('/biometria/treinar', { method: 'POST', body: { nome, descriptor: descriptorPendente } });
  status(ok ? 'Rosto cadastrado com sucesso!' : `Erro ao salvar: ${dados?.erro}`, ok ? 'ok' : 'perigo');
  if (ok) { enviarEventoBackend('Moradores', `Novo morador cadastrado: ${nome}`); carregarMoradores(); }
}

// ---------------- Ativar IA (reconhecimento contínuo) ----------------
function iniciarReconhecimento() {
  if (intervaloReconhecimento) return pararReconhecimento();
  if (!modelosCarregados) return status('A IA de rosto ainda está carregando…', 'atencao');
  $('btnLigarIA').setAttribute('aria-pressed', 'true');
  status('Monitoramento IA ativado. Procurando rostos…');
  enviarEventoBackend('Reconhecimento Facial', `IA ativada na câmera "${cameraAberta.nome}"`);

  intervaloReconhecimento = setInterval(async () => {
    if (estadoSistema.alertaPolicial || analisando) return;
    analisando = true; // só começa uma leitura nova quando a anterior terminar
    try { await analisarQuadro(); } finally { analisando = false; }
  }, 1500);
}

// Uma leitura: acha o rosto, pergunta à API do Davi e reage na tela.
async function analisarQuadro() {
  if (!intervaloReconhecimento) return;
  let rosto = null;
  try { rosto = await lerRosto(); } catch { /* quadro com problema: tenta no próximo */ }
  desenharRosto(rosto);
  if (!rosto) {
    // Um quadro sem rosto (piscada, movimento) não apaga o último resultado na hora.
    if (Date.now() - ultimoRostoVisto > 3000) status('Procurando rostos…');
    return;
  }
  ultimoRostoVisto = Date.now();

  // Pergunta à API do Davi. Só grava no histórico quando a pessoa muda (ou a cada 30 s).
  const consulta = async (registrar) => api('/biometria/autenticar', {
    method: 'POST', body: { descriptorLeitura: Array.from(rosto.descriptor), camera: cameraAberta.nome, registrar }
  });
  let resultado = await consulta(false);
  const chave = resultado.dados?.usuario || resultado.dados?.status;
  if (chave !== ultimoRegistro.chave || Date.now() - ultimoRegistro.quando > 30000) {
    ultimoRegistro = { chave, quando: Date.now() };
    resultado = await consulta(true);
    if (resultado.dados?.status === 'LIBERADO') simularMorador(resultado.dados.usuario);
    if (resultado.dados?.status === 'NEGADO') simularDesconhecido();
  }
  if (resultado.dados?.status === 'LIBERADO') status(`LIBERADO: ${resultado.dados.usuario}`, 'ok');
  else if (resultado.dados?.status === 'NEGADO') status('DESCONHECIDO — ACESSO NEGADO', 'atencao');
  else status('Servidor fora do ar', 'perigo');
}

function pararReconhecimento() {
  clearInterval(intervaloReconhecimento);
  intervaloReconhecimento = null;
  $('btnLigarIA').setAttribute('aria-pressed', 'false');
  desenharRosto(null);
}

// Caixa em volta do rosto, por cima do vídeo.
function desenharRosto(rosto) {
  const canvas = $('overlay'), video = $('webcam');
  canvas.width = canvas.clientWidth;
  canvas.height = canvas.clientHeight;
  if (!rosto || !video.videoWidth) return;
  const escala = Math.min(canvas.width / video.videoWidth, canvas.height / video.videoHeight);
  const ox = (canvas.width - video.videoWidth * escala) / 2, oy = (canvas.height - video.videoHeight * escala) / 2;
  const b = rosto.detection.box;
  const ctx = canvas.getContext('2d');
  ctx.strokeStyle = '#22D3EE';
  ctx.lineWidth = 2.5;
  ctx.strokeRect(ox + b.x * escala, oy + b.y * escala, b.width * escala, b.height * escala);
}

// Morador reconhecido: libera a porta (só na câmera da entrada) e tranca de novo em 15 s.
function simularMorador(nome = 'Morador') {
  if (estadoSistema.alertaPolicial) return; // não libera se houver alerta policial
  $('lastAccess').textContent = `${nome} (${hora()})`;
  enviarEventoBackend('Reconhecimento Facial', `MORADOR AUTORIZADO: ${nome}`);
  if (/entrada|porta|frente/i.test(cameraAberta?.nome || '') && !estadoSistema.portaPrincipal) {
    togglePorta();
    clearTimeout(timerPorta);
    timerPorta = setTimeout(() => estadoSistema.portaPrincipal && togglePorta(), 15000);
  }
}

function simularDesconhecido() {
  $('lastAccess').textContent = `Pessoa não cadastrada (${hora()})`;
  enviarEventoBackend('Reconhecimento Facial', 'ACESSO NEGADO - DESCONHECIDO');
}

// ---------------- moradores e acessos ----------------
async function carregarMoradores() {
  const [moradores, acessos] = await Promise.all([api('/biometria/moradores'), api('/biometria/acessos')]).catch(() => [{}, {}]);
  moradoresCadastrados = moradores.ok ? moradores.dados : [];

  $('listaMoradores').innerHTML = moradoresCadastrados.length ? '' : '<li class="vazio">Ninguém cadastrado ainda.</li>';
  for (const m of moradoresCadastrados) {
    const li = document.createElement('li');
    li.innerHTML = `<span class="morador-inicial"></span><span class="morador-info"><strong></strong><small>Rosto cadastrado</small></span>
      <button class="icone-botao morador-remover" type="button" aria-label="Remover morador"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg></button>`;
    li.querySelector('.morador-inicial').textContent = m.nome[0].toUpperCase();
    li.querySelector('strong').textContent = m.nome;
    li.querySelector('button').onclick = async () => {
      if (!confirm(`Remover ${m.nome}? O rosto deixa de ser reconhecido.`)) return;
      await api(`/biometria/moradores/${m.id}`, { method: 'DELETE' });
      carregarMoradores();
    };
    $('listaMoradores').appendChild(li);
  }

  const ROTULO = { LIBERADO: ['ok', 'Liberado'], NEGADO: ['atencao', 'Não reconhecido'], PROCURADO: ['perigo', 'Procurado'] };
  const lista = acessos.ok ? acessos.dados : [];
  $('listaAcessos').innerHTML = lista.length ? '' : '<li class="vazio">Nenhum acesso registrado ainda.</li>';
  for (const a of lista) {
    const li = document.createElement('li');
    li.dataset.tom = ROTULO[a.resultado][0];
    li.innerHTML = '<time></time><span><strong></strong> — <em></em></span>';
    li.querySelector('time').textContent = a.criado_em.substring(11, 16);
    li.querySelector('strong').textContent = ROTULO[a.resultado][1];
    li.querySelector('em').textContent = `${a.nome || 'pessoa desconhecida'} (${a.camera})`;
    $('listaAcessos').appendChild(li);
  }
}

window.addEventListener('DOMContentLoaded', () => {
  if (!getSession()) return;
  carregarModelosIA();
  carregarMoradores();
  aoConectarSocket((s) => {
    s.on('acesso:novo', carregarMoradores);
    s.on('morador:novo', carregarMoradores);
    iniciarCelulares(s, abrirCamera);
  });
});
