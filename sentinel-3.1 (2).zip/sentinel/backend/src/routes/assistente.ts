import { Router } from 'express';
import { exigirLogin, RequisicaoComUsuario } from '../autenticacao';
import { configuracaoLlama, conversar } from '../assistente/llama';

const router = Router();

// Limite simples: no máximo 20 mensagens por minuto por usuário.
const pedidos = new Map<number, number[]>();
function passouDoLimite(usuarioId: number) {
  const agora = Date.now();
  const recentes = (pedidos.get(usuarioId) || []).filter(t => agora - t < 60000);
  recentes.push(agora);
  pedidos.set(usuarioId, recentes);
  return recentes.length > 20;
}

/**
 * @swagger
 * /api/assistente/status:
 *   get:
 *     summary: Diz se o Llama (Ollama) está configurado e qual modelo
 *     tags: [Assistente]
 */
router.get('/assistente/status', (_req, res) => {
  const { ativa, modelo } = configuracaoLlama();
  res.json({ llama: ativa, modelo });
});

/**
 * @swagger
 * /api/assistente/mensagem:
 *   post:
 *     summary: Conversa com o Llama (exige login)
 *     description: O Llama responde e pode usar ferramentas para consultar o banco ou pedir ações ao painel.
 *     tags: [Assistente]
 *     requestBody:
 *       content:
 *         application/json:
 *           example: { "mensagens": [{ "papel": "usuario", "texto": "como está a casa?" }], "estado": { "portaPrincipal": false, "risco": 10 } }
 *     responses:
 *       200: { description: Resposta do Llama e a lista de ações para o painel }
 *       503: { description: Ollama fechado ou não configurado }
 */
router.post('/assistente/mensagem', exigirLogin, async (req: RequisicaoComUsuario, res) => {
  const { mensagens = [], estado = {} } = req.body;
  if (!Array.isArray(mensagens) || !mensagens.length) return res.status(400).json({ erro: 'Mensagem vazia.' });
  if (passouDoLimite(req.usuario!.id)) return res.status(429).json({ erro: 'Muitas mensagens seguidas. Espere um minuto.' });
  if (!configuracaoLlama().ativa) return res.status(503).json({ erro: 'O Llama não está configurado. Coloque OLLAMA_URL no .env.' });

  try {
    const { resposta, acoes, modelo } = await conversar(mensagens, estado, req.usuario!.nome);
    res.json({ resposta, acoes, origem: `Llama (${modelo})` });
  } catch (erro: any) {
    console.warn('Llama não respondeu:', erro.message);
    res.status(503).json({ erro: 'O Llama não respondeu. Confira se o Ollama está aberto.' });
  }
});

export default router;
